# Atom - Japanese Menu

Atom のメニューバーとコンテキストメニュー、設定画面を日本語化します。

![screenshot](https://github.com/syon/atom-japanese-menu/raw/master/screenshot.png)

![screenshot](https://github.com/syon/atom-japanese-menu/raw/master/screenshot2.png)

![screenshot](https://github.com/syon/atom-japanese-menu/raw/master/screenshot3.png)
