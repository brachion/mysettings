# Trailing Spaces

Highlights trailing whitespace.

## Installation ##

Use the Atom package manager, which can be found in the Settings view or run `apm install trailing-spaces`  from the command line.

## Configuration ##

Configuration options are available for:
- Enable/disable highlight on lines with a cursor
- Enable/disable highlight on lines which contain only indentation

## Screenshot ##

![](http://snag.gy/OpJpI.jpg)

